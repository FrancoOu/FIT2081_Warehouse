package com.example.firstapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    EditText itemName;
    EditText quantity;
    EditText cost;
    EditText description;
    EditText location;
    ToggleButton toggleButton;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        itemName = findViewById(R.id.ItemName);
        quantity = findViewById(R.id.Quantity);
        cost = findViewById(R.id.Cost);
        description = findViewById(R.id.Description);
        toggleButton = findViewById(R.id.toggleButton);
        location= findViewById(R.id.Location);

        sp = getSharedPreferences("Data",0);
        itemName.setText(sp.getString("itemName",""));
        quantity.setText(sp.getString("quantity",""));
        cost.setText(sp.getString("cost",""));
        description.setText(sp.getString("description",""));
        location.setText(sp.getString("location",""));
        toggleButton.setChecked(sp.getBoolean("frozen",false));

    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    public void saveItem(View view){
        Context context = getApplicationContext();
        CharSequence text = "New item"+" ("+itemName.getText()+") "+"have been added.";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        sp = getSharedPreferences("Data",0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("itemName",itemName.getText().toString());
        editor.putString("quantity",quantity.getText().toString());
        editor.putString("cost",cost.getText().toString());
        editor.putString("description",description.getText().toString());
        editor.putString("location",location.getText().toString());
        editor.putBoolean("frozen",toggleButton.isChecked());
        editor.commit();

    }
    public void clear(View view){
        itemName.getText().clear();
        quantity.getText().clear();
        cost.getText().clear();
        description.getText().clear();
        location.getText().clear();
        toggleButton.setChecked(false);
        sp = getSharedPreferences("Data",0);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        editor.commit();


    }



    @Override
    protected void onStop() {
        super.onStop();


    }
}